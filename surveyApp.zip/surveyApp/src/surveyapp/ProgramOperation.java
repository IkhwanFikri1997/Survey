/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package surveyapp;
import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.JRadioButton;
/**
 *
 * @author Ikhwan Fikri Emerald
 */
public class ProgramOperation {
    public void SwitchPanel(JPanel input, JPanel add){
        input.add(add);
        input.revalidate();
        input.repaint();
    }
}
