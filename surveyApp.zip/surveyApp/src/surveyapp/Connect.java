/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package surveyapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Ikhwan Fikri Emerald
 */
public class Connect extends ProgramOperation{
    Connection con,cons,cont;
    Statement stm,stms,stmt;
    
    public void linkQuestion(){
        String url = "jdbc:mysql://localhost:3306/survey?zeroDateTimeBehavior=convertToNull";
        String name = "root";
        String pswd = "";
        
        try{
            con = DriverManager.getConnection(url, name, pswd);
            stm = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e){JOptionPane.showMessageDialog(null, e);}
    }
    
    public void linkReport(){
        String url = "jdbc:mysql://localhost:3306/report?zeroDateTimeBehavior=convertToNull";
        String name = "root";
        String pswd = "";
        
        try{
            cons = DriverManager.getConnection(url, name, pswd);
            stms = cons.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e){JOptionPane.showMessageDialog(null, e);}
    }
    
    public void linkSurveyList()
    {
        String url = "jdbc:mysql://localhost:3306/username?zeroDateTimeBehavior=convertToNull";
        String uname = "root";
        String password = "";
        try {
            cont = DriverManager.getConnection(url, uname, password);
            stmt = cont.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        } catch(SQLException err){JOptionPane.showMessageDialog(null,err.getMessage());}
    }
    
}
