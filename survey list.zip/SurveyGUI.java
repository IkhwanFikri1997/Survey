/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package surveyapp;

import java.awt.Component;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Eric
 */
public class SurveyGUI extends javax.swing.JFrame {

    DefaultTableModel dtm = new DefaultTableModel();
    Connection con,cons, con2;
    Statement stm,stmt, stm2;
    ResultSet rs,rs2;
    public int qNum=1;
    public static String title;
    /**
     * Creates new form SurveyGUI
     */
    public SurveyGUI() {
        initComponents();
        fillCombo();
        groupButton();
        startPoint();
        linkQuestion();
        linkReport();
        linkSurveyList();
    }
    
    public void groupButton(){
        // only 1 choice enabled when clicked
        ButtonGroup bg1 = new ButtonGroup();
        bg1.add(jRadioButton1);
        bg1.add(jRadioButton2);
        bg1.add(jRadioButton3);
        bg1.add(jRadioButton4);
    }
    
    public void linkSurveyList(){
        String url = "jdbc:mysql://localhost:3306/stuff?zeroDateTimeBehavior=convertToNull";
        String name = "root";
        String pswd = "";
        
        try{
            con2 = DriverManager.getConnection(url, name, pswd);
            stm2 = con2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e){JOptionPane.showMessageDialog(this, e);}
    }
    
    public void linkQuestion(){
        String url = "jdbc:mysql://localhost:3306/survey?zeroDateTimeBehavior=convertToNull";
        String name = "root";
        String pswd = "";
        
        try{
            con = DriverManager.getConnection(url, name, pswd);
            stm = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e){JOptionPane.showMessageDialog(this, e);}
    }
    
    public void makeTable() throws SQLException{
        //make new table
        title = surveyTitle.getText().toLowerCase();
        
        String query = "create table `"+title+"`("
                           +"question varchar(255),"
                           +"type int(4),"
                           +"choice1 varchar(255),"
                           +"choice2 varchar(255),"
                           +"choice3 varchar(255),"
                           +"choice4 varchar(255));";
        
        stm.executeUpdate(query);
        
        String query2 = "insert into `survey data` values('" +title+ "')";
        stm2.executeUpdate(query2);
        
        JOptionPane.showMessageDialog(this, "question table made");
    }
    
    public void startPoint(){
        motherPanel.removeAll();
        choicePanel.setVisible(false);
        
        jLabel2.setText("Question "+qNum);
        jLabel3.setText("Question "+qNum);
        jLabel4.setText("Question "+qNum);
        
        jCheckBox1.setText("choice 1");
        jCheckBox2.setText("choice 2");
        jCheckBox3.setText("choice 3");
        jCheckBox4.setText("choice 4");
        
        jRadioButton1.setText("choice 1");
        jRadioButton2.setText("choice 2");
        jRadioButton3.setText("choice 3");
        jRadioButton4.setText("choice 4");
    }

    public void fillCombo(){
        // fill combo box
        typeBox.addItem("1. Checkbox");
        typeBox.addItem("2. Textbox");
        typeBox.addItem("3. Radio Button");
    }
    
    public void linkReport(){
        String url = "jdbc:mysql://localhost:3306/report?zeroDateTimeBehavior=convertToNull";
        String name = "root";
        String pswd = "";
        
        try{
            cons = DriverManager.getConnection(url, name, pswd);
            stmt = cons.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e){JOptionPane.showMessageDialog(this, e);}
    }
    
    public void MakeRecord(){
        try {
        title = surveyTitle.getText().toLowerCase();
        String query = "create table `"+title+" report`("
                           +"person int(10));";
        
        stmt.executeUpdate(query);
        String select = "select question from `"+title+"`";
        rs = stm.executeQuery(select);
        rs.beforeFirst();
        while (rs.next()){
        String Ask = rs.getString("question");
        String report = "alter table `"+title+" report`\n"
                            +" add `"+Ask+"` varchar(255);";
        stmt.executeUpdate(report);
        }
        JOptionPane.showMessageDialog(this, "report table made");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(this, e);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        radioPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        checkPanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        textPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        typeBox = new javax.swing.JComboBox<>();
        motherPanel = new javax.swing.JPanel();
        questionBox = new javax.swing.JTextField();
        choicePanel = new javax.swing.JPanel();
        c1 = new javax.swing.JTextField();
        c2 = new javax.swing.JTextField();
        c3 = new javax.swing.JTextField();
        c4 = new javax.swing.JTextField();
        next = new javax.swing.JButton();
        saveSurvey = new javax.swing.JButton();
        set = new javax.swing.JButton();
        surveyTitle = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        surveyTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        jRadioButton1.setText("choice 1");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setText("choice 2");

        jRadioButton4.setText("choice 4");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });

        jRadioButton3.setText("choice 3");

        javax.swing.GroupLayout radioPanelLayout = new javax.swing.GroupLayout(radioPanel);
        radioPanel.setLayout(radioPanelLayout);
        radioPanelLayout.setHorizontalGroup(
            radioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(radioPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(radioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton4)
                    .addComponent(jRadioButton3))
                .addContainerGap(229, Short.MAX_VALUE))
        );
        radioPanelLayout.setVerticalGroup(
            radioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, radioPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton4)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jLabel3.setText("jLabel3");

        jCheckBox1.setText("choice 1");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("choice 2");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setText("choice 3");

        jCheckBox4.setText("choice 4");

        javax.swing.GroupLayout checkPanelLayout = new javax.swing.GroupLayout(checkPanel);
        checkPanel.setLayout(checkPanelLayout);
        checkPanelLayout.setHorizontalGroup(
            checkPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(checkPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(checkPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox2)
                    .addComponent(jCheckBox3)
                    .addComponent(jCheckBox4)
                    .addComponent(jLabel3))
                .addContainerGap(229, Short.MAX_VALUE))
        );
        checkPanelLayout.setVerticalGroup(
            checkPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, checkPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jCheckBox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox4)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jLabel4.setText("jLabel4");

        javax.swing.GroupLayout textPanelLayout = new javax.swing.GroupLayout(textPanel);
        textPanel.setLayout(textPanelLayout);
        textPanelLayout.setHorizontalGroup(
            textPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(textPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(textPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(76, Short.MAX_VALUE))
        );
        textPanelLayout.setVerticalGroup(
            textPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(textPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(152, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        typeBox.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        typeBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select type" }));
        typeBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                typeBoxPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        typeBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeBoxActionPerformed(evt);
            }
        });

        motherPanel.setLayout(new java.awt.CardLayout());

        questionBox.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        questionBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                questionBoxActionPerformed(evt);
            }
        });

        c2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout choicePanelLayout = new javax.swing.GroupLayout(choicePanel);
        choicePanel.setLayout(choicePanelLayout);
        choicePanelLayout.setHorizontalGroup(
            choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(choicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(c4, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                    .addComponent(c3)
                    .addComponent(c2)
                    .addComponent(c1))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        choicePanelLayout.setVerticalGroup(
            choicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(choicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(c1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(c4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        next.setText("Next");
        next.setEnabled(false);
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        saveSurvey.setText("Save");
        saveSurvey.setEnabled(false);
        saveSurvey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveSurveyActionPerformed(evt);
            }
        });

        set.setText("Set");
        set.setEnabled(false);
        set.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setActionPerformed(evt);
            }
        });

        surveyTitle.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N

        surveyTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Question", "Type", "Choice 1", "Choice 2", "Choice 3", "Choice 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        surveyTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(surveyTable);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("Title");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel5.setText("Question");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(set)
                        .addGap(185, 185, 185)
                        .addComponent(next)
                        .addGap(18, 18, 18)
                        .addComponent(saveSurvey)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(choicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(typeBox, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(surveyTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(questionBox, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 873, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(motherPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(938, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 25, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(surveyTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(typeBox, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(questionBox)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(choicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(next)
                            .addComponent(saveSurvey)
                            .addComponent(set))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(161, 161, 161)
                    .addComponent(motherPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(220, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void setActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setActionPerformed
        // validation
        int sel = typeBox.getSelectedIndex();
        
        if(questionBox.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Question box must be filled");
        }
        
        // set choices
        else{
            // apply choices based on combobox index
            switch(sel){
                case 1 : 
                if(c1.getText().equals("") || c2.getText().equals("")){
                    JOptionPane.showMessageDialog(this, "2 top choices must be filled");
                }
                    
                else{
                    next.setEnabled(true);
                    jLabel3.setText(questionBox.getText());
                    jCheckBox1.setText(c1.getText());
                    jCheckBox2.setText(c2.getText());
                    jCheckBox3.setText(c3.getText());

                    if(c3.getText().equals("")){
                        jCheckBox3.setVisible(false);
                    }
                    else{jCheckBox3.setVisible(true);}
                    jCheckBox4.setText(c4.getText());

                    if(c4.getText().equals("")){
                        jCheckBox4.setVisible(false);
                    }
                    else{jCheckBox4.setVisible(true);}
                }
                break;
                case 2 :
                next.setEnabled(true);
                jLabel4.setText(questionBox.getText());
                break;
                case 3 :
                if(c1.getText().equals("") || c2.getText().equals("")){
                    JOptionPane.showMessageDialog(this, "2 top choices must be filled");
                }    
                    
                else{
                    next.setEnabled(true);
                    jLabel2.setText(questionBox.getText());
                    jRadioButton1.setText(c1.getText());
                    jRadioButton2.setText(c2.getText());
                    jRadioButton3.setText(c3.getText());
                    
                    if(c3.getText().equals("")){
                        jRadioButton3.setVisible(false);
                    }
                    else{jRadioButton3.setVisible(true);}

                    jRadioButton4.setText(c4.getText());
                    if(c4.getText().equals("")){
                        jRadioButton4.setVisible(false);
                    }
                    else{jRadioButton4.setVisible(true);}
                }
                break;
            }
        }
    }//GEN-LAST:event_setActionPerformed

    private void c2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c2ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void typeBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeBoxActionPerformed

    private void typeBoxPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_typeBoxPopupMenuWillBecomeInvisible
        // select survey type
        int sel = typeBox.getSelectedIndex();

        switch(sel){
            //disable all
            case 0 : startPoint();
                     next.setEnabled(false);
                     set.setEnabled(false);
                     break;
            //enable checkbox
            case 1 : motherPanel.removeAll();
            motherPanel.add(checkPanel);
            motherPanel.repaint();
            motherPanel.revalidate();
            choicePanel.setVisible(true);
            next.setEnabled(false);
            set.setEnabled(true);
            break;
            //enable textbox
            case 2 : motherPanel.removeAll();
            motherPanel.add(textPanel);
            motherPanel.repaint();
            motherPanel.revalidate();
            choicePanel.setVisible(false);
            set.setEnabled(true);
            break;
            //enable radio
            case 3 : motherPanel.removeAll();
            motherPanel.add(radioPanel);
            motherPanel.repaint();
            motherPanel.revalidate();
            choicePanel.setVisible(true);
            next.setEnabled(false);
            set.setEnabled(true);
            break;
        }
    }//GEN-LAST:event_typeBoxPopupMenuWillBecomeInvisible

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
        //minimum survey limit 3 questions
        boolean sameQuestion = false;
        qNum+=1;
        next.setEnabled(false);
        if(surveyTable.getRowCount()>=2){
            saveSurvey.setEnabled(true);
        }
        
        //save question to table
        String nQuestion = questionBox.getText();

        int type = typeBox.getSelectedIndex();
        // 0=null 1=check 2=text 3=radio

        String ch1 = c1.getText();
        String ch2 = c2.getText();
        String ch3 = c3.getText();
        String ch4 = c4.getText();
        
        // check for duplicate question
        for(int i = 0; i<surveyTable.getRowCount();i++){
            if(questionBox.getText().equals((String)surveyTable.getValueAt(i, 0))){
                sameQuestion = true;
            }
        }
        
        if(sameQuestion){
            JOptionPane.showMessageDialog(this, "Duplicate question");
        }
        
        else{
            dtm = (DefaultTableModel) surveyTable.getModel();
            if(type==2){
                dtm.addRow(new Object[]{nQuestion, type});
            }
            else{
                dtm.addRow(new Object[]{nQuestion, type,ch1,ch2,ch3,ch4});
            }
        }

        // make more questions
        questionBox.setText("");
        c1.setText("");
        c2.setText("");
        c3.setText("");
        c4.setText("");
        typeBox.setSelectedIndex(0);

        startPoint();
    }//GEN-LAST:event_nextActionPerformed

    private void saveSurveyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveSurveyActionPerformed
        //save survey to database
        int row = surveyTable.getRowCount();
        title = surveyTitle.getText();
        if(title.equals("")){
            JOptionPane.showMessageDialog(this, "Empty title");
        }
        
        else{
            try{
            makeTable();
            //JOptionPane.showMessageDialog(this, "insertion");

            for(int i=0; i<row; i++){
                String name = (String)surveyTable.getValueAt(i, 0);
                int type = (int)surveyTable.getValueAt(i, 1);
                String choice1 = (String)surveyTable.getValueAt(i, 2);
                String choice2 = (String)surveyTable.getValueAt(i, 3);
                String choice3 = (String)surveyTable.getValueAt(i, 4);
                String choice4 = (String)surveyTable.getValueAt(i, 5);

                stm.executeUpdate("insert into `" +title+ "` values('"+name+"'," +type+ ",'"+choice1+"'," +"'"+choice2+"'," +"'"+choice3+"'," +"'"+choice4+"')");
            }
            JOptionPane.showMessageDialog(this, "Save successful");
            startPoint();
            MakeRecord();
            this.setVisible(false);
            SurveyProgram survey = new SurveyProgram();
            survey.setVisible(true);
            }catch(SQLException e){JOptionPane.showMessageDialog(this, e);}
        }
    }//GEN-LAST:event_saveSurveyActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void questionBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_questionBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_questionBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SurveyGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SurveyGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SurveyGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SurveyGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SurveyGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField c1;
    private javax.swing.JTextField c2;
    private javax.swing.JTextField c3;
    private javax.swing.JTextField c4;
    private javax.swing.JPanel checkPanel;
    private javax.swing.JPanel choicePanel;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPanel motherPanel;
    private javax.swing.JButton next;
    private javax.swing.JTextField questionBox;
    private javax.swing.JPanel radioPanel;
    private javax.swing.JButton saveSurvey;
    private javax.swing.JButton set;
    private javax.swing.JTable surveyTable;
    private javax.swing.JTextField surveyTitle;
    private javax.swing.JPanel textPanel;
    private javax.swing.JComboBox<String> typeBox;
    // End of variables declaration//GEN-END:variables
}
