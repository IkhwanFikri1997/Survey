/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package surveyapp;

import java.util.ArrayList;

/**
 *
 * @author Eric
 */
public class surveyData {
    ArrayList<String> questions;
    ArrayList<String> checkChoice;
    ArrayList<String> radioChoice;
}
